% close all; clear all;
% load('stress_num.mat')

ppg = ir_ear(:);
fsPPG = 25;

mark = [1 350 1050]; % End: floor(numel(ppg)/fsPPG)

% Three Stage: Pre-rest, during stessor imposing, post-rest
label = {'rest', 'math', 'rest'};

param = struct('thS', 60, 'thK', 6, 'miniInvalidInterval', 8,...
    'thParam', 1.3, 'winLength1', 1,...
    'fsPPI', 4, 'winLength2', 4, 'anomParam', 0.35);

global T
T = struct2table(param);
T.Properties.RowNames = {'Current value'};

% PPG --> HRV
[hrv, markA] = fPPG2HRV(ppg, fsPPG, mark);
markA = [ceil(markA.*T.fsPPI), numel(hrv)];
% HRV --> LF & HF
% Both PNS and SNS activity contribute to LF power, and PNS activity primarily contributes to HF power.
%% Wavelet
hrvMetrics_ref = fHRV2SpectralParam(hrv(1:end), T.fsPPI, 0.999);
%% HHT
hrvMetrics = fHRV2SpectralParam(hrv(1:end), T.fsPPI, 0.98);
%%
hrvMetricsTbl = [];
name = {'percent'};
for i = 1:numel(markA)
    userSatisfaction = 0;
    hrvSeg = hrv(markA(i): markA(i+1)-1);
    hrvMetrics = fHRV2SpectralParam(hrvSeg, T.fsPPI, percent);
    while ~userSatisfaction
        userFB = input('Change parameters? (Y/N): ', 's');
        if strcmpi('Y', userFB)
            n = input('Which parameter?: ', 's');
            if ~any(strcmpi(n, name), 'all') 
                disp('Unrecognized parameter name')
            else
                v = input('Input value: ');
                eval(['hrvMetrics = fHRV2SpectralParam(hrvSeg, T.fsPPI,' num2str(v) ');']);
            end
        elseif strcmpi('N', userFB)
            userSatisfaction = 1;
        else
            disp('Unrecognized input')
        end
    end
    hrvMetrics.label = repmat(label(i), numel(hrvMetrics.LF), 1);
    hrvMetricsTbl = [hrvMetricsTbl; struct2table(hrvMetrics)];
end

