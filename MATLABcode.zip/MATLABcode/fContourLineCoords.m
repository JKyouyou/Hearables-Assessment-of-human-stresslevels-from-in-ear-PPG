function contourArray = fContourLineCoords(cm)
if ishandle(cm)
    cm = cm.ContourMatrix;
end

numCols = size(cm, 2);   	
r = 0; 
contourArray = {};   

% Extract coordinates of each contour line
while r < numCols
    l = r + 1;
    r = r + cm(2,l) + 1;
    contourArray(end+1) = {cm(:, l:r).'};  %#ok<AGROW>
end

contourArray = cellfun(@(c)[c(2:end,:); c(2,:)],contourArray,'UniformOutput',false);

for i = 1:numel(contourArray)
    temp = contourArray{i};
    if (temp(end-1,1) == 0.25) && (temp(end,2) == 0.5)
        contourArray{i} = [contourArray{i}(1:end-1, :); [0.25, 0.5]; contourArray{i}(end, :)];
    end
end