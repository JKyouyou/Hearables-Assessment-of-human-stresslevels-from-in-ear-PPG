function [hrvMetrics, ind] = fHRV2SpectralParam(hrv, fsHRV, percent)

% LF Power in low-frequency band 0.04–0.15 Hz, HF Power in high-frequency band 0.15–0.4 Hz
fLow = 0.04; fHigh = 0.4; fBoundary = 0.15;
numIMF = 2;
imf = emd(hrv, 'Display', 0, 'MaxNumIMF', numIMF);
[~, ~, t, imfInsF, imfInsE] = hht(imf, fsHRV);

figure
hht(imf, fsHRV, 'FrequencyLimits', [0.04 0.4])
line([t(1), t(end)], [0.15, 0.15], 'Color', 'k', 'LineStyle', '--', 'LineWidth', 1) % LF & HF boundary
caxis([0, max(imfInsE((imfInsF <= fHigh) & (imfInsF >= fBoundary)))])

% Focus on 0.15 - 0.4 Hz
imfInsE_HF = imfInsE;
imfInsE_HF(~((imfInsF <= fHigh) & (imfInsF >= fBoundary))) = 0;  
HF_sort = sort(reshape(imfInsE_HF, 1, []));
% Find threshold
ind_HF = (imfInsE_HF > HF_sort(ceil(end*percent)));
% Focus on 0.04 - 0.15 Hz
imfInsE_LF = imfInsE;
imfInsE_LF(~((imfInsF <= fBoundary) & (imfInsF >= fLow))) = 0;  
LF_sort = sort(reshape(imfInsE_LF, 1, []));
% Find threshold
ind_LF = (imfInsE_LF > LF_sort(ceil(end*percent)));

ind = ind_HF | ind_LF;

miniDuration = ceil(fsHRV*15);
% Filter the "ind"
for i = 1: numIMF
    ind_temp = ind(:,i);
    d = diff([0; ind_temp; 0]);
    bndry.right = find(d<0); bndry.left = find(d>0); dur = bndry.right-bndry.left;
    for ii = 1: numel(dur)
        if dur(ii) > miniDuration % Anomlies lasting for a long time will not be considered as anomlies
            ind(bndry.left(ii):bndry.right(ii), i) = 0;
        end
    end
end
% Label anomlies
hold on
for i = 1: numIMF
    imfInsF_temp = imfInsF(:,i); imfInsF_temp(~ind(:,i)) = NaN;
    plot(t, imfInsF_temp, 'Color', [0, 0, 0, 0.3], 'LineWidth', 2.5);
end
imfInsE(ind) = NaN;

% HRV Spectral Metrics
imfInsE_HF = imfInsE; imfInsE_HF(~((imfInsF <= fBoundary) & (imfInsF >= fLow))) = 0;
insE_LF = sum(imfInsE_HF, 2, 'omitnan');

imfInsE_HF = imfInsE; imfInsE_HF(~((imfInsF <= fHigh) & (imfInsF >= fBoundary))) = 0;
insE_HF = sum(imfInsE_HF, 2, 'omitnan');

inc = 4; % Increment: 4 samples (1 sec)
L = numel(insE_LF);
numSamples = ceil(120*fsHRV);
if L < numSamples
    warning('HRV should be recorded over a minimum 125 sec-period')
    numSamples = L;
end

% Average values found by a sliding window
steps = 0: ceil(inc*fsHRV): (L-numSamples);
numSteps = numel(steps);
LF = zeros(numSteps, 1); HF = zeros(numSteps, 1); HR = zeros(numSteps, 1);
for i = 1:numSteps
    l = steps(i)+1;
    r = min(steps(i)+numSamples, L);
    
    LF(i) = sum(mean(insE_LF(l:r)));
    HF(i) = sum(mean(insE_HF(l:r)));
    
    HR(i) = 60./mean(hrv(l:r));
end

hrvMetrics.LF = LF;
hrvMetrics.HF = HF;
hrvMetrics.HR = HR;

