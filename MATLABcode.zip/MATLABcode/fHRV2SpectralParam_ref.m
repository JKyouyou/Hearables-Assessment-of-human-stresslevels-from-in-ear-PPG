function hrvMetrics = fHRV2SpectralParam_ref(hrv, fsHRV, percent)

figure
[wt, f] = cwt(hrv, fsHRV, 'VoicesPerOctave', 8, 'FrequencyLimits', [0.04 0.4]);
wt = abs(wt);
t = (1: numel(hrv))/fsHRV;
hp = pcolor(t, f, wt);
hp.EdgeAlpha = 0;
colorbar
axis tight
title('Scalogram and Instantaneous Frequencies'), xlabel('Seconds'), ylabel('Hz');

hold on
[X,Y] = meshgrid(t, f);
wtSort = sort(reshape(wt, 1, []));
thW = wtSort(ceil(end*percent)); % .99 used for good-quality signal
[c, h] = contour(X, Y, abs(wt), [0, thW], 'w');

line([t(1), t(end)], [0.15, 0.15], 'Color', 'w', 'LineStyle', '--', 'LineWidth', 1)


set(h,'LineColor','none')
contourArray = fContourLineCoords(c);
xJoint = []; yJoint = [];
miniDuration = 15;
hold on
for i = 1:numel(contourArray)
    x = contourArray{i}(:,1); y = contourArray{i}(:,2);
    if (max(x) - min(x)) < miniDuration
        plot(x, y, 'Color', [1, 1, 1, 0.8], 'LineWidth', 2)
        xJoint = [xJoint; NaN; x]; yJoint = [yJoint; NaN; y];
    end
end

if ~isempty(xJoint) % No abnormalities detected on scalogram
    xJoint(1,:) = []; yJoint(1,:) = [];
    yQue = repmat(f, numel(t), 1); xQue = kron(t.', ones(numel(f), 1));
    
    [in,on] = inpolygon(xQue, yQue, xJoint, yJoint);
    inon = ~(in | on);
    P = double(reshape(inon, numel(f), numel(t)));
    P(P == 0) = NaN;
    wtFilt = double(P).*wt;
else
    wtFilt = wt;
end


[val, idx] = min(abs(f - 0.15));
if val > 0.01
    disp('Freqency blocks is too large, increase the No. of voice in a octave');
end

numSamples = ceil(fsHRV*60);
L = size(wtFilt, 2);
if L < numSamples
    warning('HRV should be recorded over a minimum 2 min period')
    numSamples = L;
end

inc = 4;
steps = 0: ceil(inc*fsHRV): (L-numSamples);
numSteps = numel(steps);
LF = zeros(numSteps, 1); HF = zeros(numSteps, 1); HR = zeros(numSteps, 1);
for i = 1:numSteps
    l = steps(i)+1;
    r = min(steps(i)+numSamples, L);
    
    LF(i) = sum(mean(wtFilt(idx:end, l:r).^2, 2, 'omitnan'));
    HF(i) = sum(mean(wtFilt(1:idx-1, l:r).^2, 2, 'omitnan'));
    
    hrvF = hrv(l:r);
    HR(i) = 60./mean(hrvF);
    
end

hrvMetrics.LF = LF;
hrvMetrics.HF = HF;

hrvMetrics.HR = HR;
