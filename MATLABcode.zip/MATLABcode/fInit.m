function [ppg, fsPPG, thS, thK, miniInvalidInterval, thParam, winLength1,  ...
    fsPPI, winLength2, anomParam] = fInit(ppg, fsPPG, varargin)
if ~isvector(ppg)
  error('''PPG'' must be a vector.')
end
ppg = ppg(:);

if ~isscalar(fsPPG)
  error('''fsPPG'' must be a scalar.')
end
if fsPPG < 25
  disp('Warning. ''fsPPG'' is below the recommended value (<25 Hz).')
end

global T
options = table2struct(T);

% Parameters' name extraction
optionNames = fieldnames(options);

% Count arguments
numArgs = length(varargin);
% Update parameters according to input arguments
if numArgs ~= 0 
    if rem(numArgs, 2) ~= 0
        error('Function need ParameterName/Value pairs')
    else
        for pair = reshape(varargin,2,[])
            if any(strcmpi(pair{1}, optionNames), 'all') 
                eval(['options.' pair{1} '=' num2str(pair{2}) ';']);
            else
                error('Unrecognized parameter name %s', pair{1})
            end
        end
    end
end

thS = options.thS;
thK = options.thK;
miniInvalidInterval = options.miniInvalidInterval;

thParam = options.thParam;
winLength1 = options.winLength1;

fsPPI = options.fsPPI;
winLength2 = options.winLength2;
anomParam = options.anomParam;
end