function [ppgFilt, MADet] = fMARemover(ppg, fs, thS, thK, miniInvalidInterval)
L = numel(ppg);

% If there are severe movements during the recording, the standard deviation for each cycle
% will change abruptly.
numSamples = ceil(fs*2);
searchRange = ceil(1.7*fs); 
mar = ceil(1*fs); % Additional margin is allowed 
bndry.left = []; bndry.right = [];
flag = 0; 

miniInvalidInterval = ceil(miniInvalidInterval*fs);
for i = 1:L
    if (std(ppg(max(i-numSamples, 1): min(i+numSamples, L))) < thS) && (kurtosis(ppg(max(i-numSamples, 1): min(i+numSamples, L))) < thK) % Fixed threshold applied (can be adaptive)
        if flag == 0 % Left boundary detected
            if ~isempty(bndry.right) && ((i-bndry.right(end)+mar) < miniInvalidInterval)
                    bndry.right(end) = []; % Omit
            else
                ii = min(i+mar, L); 
                [~, loc] = min(ppg(ii: 1: min(ii+searchRange-1, L))); % Search forward
                bndry.left(end+1) = ii+loc-1; % Label bndry.left
             end
            flag = 1;
        elseif i == L % Regard last point as bndry.right
            bndry.right(end+1) = L;
        end
    elseif flag == 1 % Right boundary detected
        ii = max(i-mar, 1);
        [~, loc] = min(ppg(ii: -1: max(ii-searchRange+1, 1))); % Search backward
        bndry.right(end+1) = ii-loc+1; % Label bndry.right
        flag = 0;
    end
end

miniValidInterval = ceil(2*fs);
logicDec = (bndry.right-bndry.left) < miniValidInterval; 
ii = [];
for i = 1:numel(logicDec)
    if logicDec(i)
        ii(end+1) = i; % Omit
    end
end
bndry.left(ii) = []; bndry.right(ii) = [];

ppgFilt = [];
MADet = ones(L, 1);
for i = 1: numel(bndry.left)
    ppgFilt = [ppgFilt; ppg(bndry.left(i): bndry.right(i))]; % Concatenating MA-free ppg segments
    MADet(bndry.left(i): bndry.right(i)) = 0;
end
