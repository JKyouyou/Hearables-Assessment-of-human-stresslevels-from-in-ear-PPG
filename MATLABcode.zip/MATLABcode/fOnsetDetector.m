function [miniHeight, xAxisMiniHeight, peakLocs, peakAmps, ...
    onsetLocs, onsetAmps] = fOnsetDetector(x, fs, thParam, winLength)
% Find peaks
[peakAmps, peakLocs] = findpeaks(x);

xAxisMiniHeight = peakLocs/fs;

% Amplitude filter
numSamples = ceil(winLength*fs);
miniHeight = zeros(length(peakLocs), 1);
ii = [];
for i = 1:length(peakLocs)
    miniHeight(i) = thParam*mean(x(max(peakLocs(i) - numSamples, 1) : min(peakLocs(i) + numSamples, length(x)))); % Adaptive threshold
    if peakAmps(i) < miniHeight(i)
        ii(end+1) = i;
    end
end
peakLocs(ii) = []; peakAmps(ii) = []; 

% Interval filter
flag = 0;
ii = [];
miniDistance = ceil(0.4*fs);
for i = 2:length(peakLocs)
    if (peakLocs(i) - peakLocs(i-1-flag)) <  miniDistance
        ii(end+1) = i;
        flag = 1;
    else
        flag = 0;
    end
end
peakLocs(ii) = []; peakAmps(ii) = [];

% Search backward from the peak point
numSamples = ceil(0.2*fs); % Search range: 2-1.5 sec
for i = 1: length(peakLocs)
    [~, loc] = min(abs(x(peakLocs(i): -1: max(peakLocs(i)-numSamples, 1))-0.005*peakAmps(i)));
    onsetLocs(i, 1) = peakLocs(i)-loc+1;
    onsetAmps(i, 1) = x(onsetLocs(i));
end

% Convert back to time axis
peakLocs = peakLocs/fs; 
onsetLocs = onsetLocs/fs; 
end