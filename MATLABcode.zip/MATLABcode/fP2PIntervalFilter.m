function [ppi, ppiFilt, xAxisPPI] = fP2PIntervalFilter(onsetLocs, fsPPI, winLength, anomParam)
% Identified suspected anomalies in the PPI traces (e.g., the ectopic peaks) and replace by interpolated values,
ppi = diff(onsetLocs);
% PPI time series can be resampled at a lower sampling frequency 
xAxisPPI=(1 : onsetLocs(end)*fsPPI)/fsPPI;

numSamples = ceil(fsPPI*winLength);
ii = [];
L = numel(ppi);
anomDetected = 0;
for i = 2: L
    ppiMedian = median(ppi(max(1, i-numSamples): min(i+numSamples, L)));
    % If sample not within allowed range
    if ((ppi(i) > ((1+anomParam)*ppiMedian)) || (ppi(i) < (max((1-anomParam),0)*ppiMedian))) 
        ii(end+1) = i;
        anomDetected = 1;        
    end
end
ppiFilt = ppi; onsetLocsFilt = onsetLocs(1:end-1);
ppiFilt(ii) = []; onsetLocsFilt(ii) = [];

% Interp
ppi = interp1(onsetLocs(1:end-1), ppi, xAxisPPI, 'PCHIP');
if anomDetected == 1 
    ppiFilt = interp1(onsetLocsFilt, ppiFilt, xAxisPPI, 'PCHIP');
else 
    ppiFilt = [];
    disp('No anomaly detected')
end
end