function [hrv, markA] = fPPG2HRV(ppg, fsPPG, mark, varargin)

[ppg, fsPPG, thS, thK, miniInvalidInterval,...
    thParam, winLength1, fsPPI, winLength2, anomParam]= fInit(ppg, fsPPG, varargin{:});

% ---------Band pass filter (0.8-6 Hz)-----------------
[b, a] = butter(4, [0.8, 6]/(fsPPG/2), 'bandpass');
ppgBp = filtfilt(b, a, ppg); % Zero phase distortion filter
% ---------High quality signal extraction--------------
xAxis = (1: numel(ppgBp))/fsPPG;
yRange = 400;

[ppgFilt, MADet] = fMARemover(ppgBp, fsPPG, thS, thK, miniInvalidInterval);

figure
subplot(3,1,1)
plot(xAxis, ppgBp)
hold on
plot(xAxis, MADet*yRange, 'k--', 'LineWidth', 1)
xlabel('Time (sec)'), legend('Bandpass PPG', 'MA detection')
ylim([-1, 1]*yRange)
xlim([xAxis(1), xAxis(end)])

% ----------Sum slope function & Peaks and onsets detection----------
% miniDistance = 0.3;
% [peakAmps, peakLocs, miniHeight, miniHeightLocs] = fPeakDetector(ppgFilt, fsPPG, miniDistance, thParam);

sumDiff = fSumSlope(ppgFilt, fsPPG);
[miniHeight, xAxisMiniHeight, peakLocs, peakAmps, ...
    onsetLocs, onsetAmps] = fOnsetDetector(sumDiff, fsPPG, thParam, winLength1);

subplot(3,1,2)
xAxisFilt = (1: numel(ppgFilt))/fsPPG;
plot(xAxisFilt, ppgFilt), hold on
plot(xAxisFilt, sumDiff, 'r')

plot(xAxisMiniHeight, miniHeight, 'k--', 'LineWidth', 1), hold on
scatter(peakLocs, peakAmps, 4, 'k', 'o')
scatter(onsetLocs, onsetAmps, 4, 'k', '^')
axis tight
ylim([-1, 1]*yRange)
legend('MA-free ppg', 'SSF', 'Threshold', 'Peaks', 'Onsets')
xlabel('Time (sec)')

if ~isempty(mark) % Label important time instants
    for i = 1:numel(mark)
        pt = ceil(mark(i)*fsPPG);
        if MADet(pt) == 0
            ptAct = pt-numel(find(MADet(1:pt) == 1));
        else
            pt = find(MADet(pt:end) == 0, 1)+pt-1;
            if ~isempty(pt)
                ptAct = pt-numel(find(MADet(1:pt) == 1));
            else
                ptAct = numel(ppgFilt);
            end
        end
        markA(i) = ptAct/fsPPG;
        text(markA(i), 3*thS, '\downarrow Mark')
    end
else
    markA = [];
end

% ----------PPI Filter----------
[ppi, ppiFilt, xAxisPPI] = fP2PIntervalFilter(peakLocs, fsPPI, winLength2, anomParam);

subplot(3,1,3)
plot(xAxisPPI, ppi), hold on
plot(xAxisPPI, ppiFilt, 'r--')
axis tight
legend('PPI',  'Filtered PPI')
xlabel('Time (sec)')

hrv = ppiFilt;
