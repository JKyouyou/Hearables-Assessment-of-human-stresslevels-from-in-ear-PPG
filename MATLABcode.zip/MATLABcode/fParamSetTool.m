function fParamSetTool(ppgBp, fsPPG, thS, thK)

L = numel(ppgBp);
numSamples = ceil(2*fsPPG);
stdSeq = zeros(L, 1); kurSeq = zeros(L,1);
for i = 1:L
    stdSeq(i) = std(ppgBp(max(i-numSamples, 1): min(i+numSamples, L)));
    kurSeq(i) = skewness(ppgBp(max(i-numSamples, 1): min(i+numSamples, L)));
end

MAs = ones(L,1);
MAs(stdSeq < thS) = 0;

fig = figure;

xAxis = (1: numel(ppgBp))/fsPPG;

ax1 = subplot(2,1,1);
plot(xAxis, ppgBp), hold on, plot(xAxis, 400*MAs, 'k--', 'LineWidth', 1), 
legend('Bandpass PPG', 'MA detection'), ylabel('Amplitude'), xlabel('Time (s)')
ax2 = subplot(2,1,2);
plot(xAxis, stdSeq, 'LineWidth', 1), 
line([xAxis(1), xAxis(end)], [thS, thS], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1)
legend('Standard deviation', 'Threshold'), ylabel('Amplitude'), xlabel('Time (s)')

set(ax1, 'ylim', [-1 1]*400)
linkaxes([ax1 ax2],'x')
axis tight


