function [peakAmpsFilt, peakLocsFilt, miniHeight, miniHeightLocs] = fPeakDetector(ppgFilt, fs, miniDistance, thParam)

[peakAmps, peakLocs] = findpeaks(ppgFilt);

% Amplitude filter
numSamples = ceil(3*fs);
miniHeight = zeros(length(peakLocs), 1);
peakAmpsFilt = [];
peakLocsFilt = [];
for i = 1:length(peakLocs)
    miniHeight(i) = thParam*std(ppgFilt(max(peakLocs(i) - numSamples, 1) : min(peakLocs(i) + numSamples, length(ppgFilt)))); % Adaptive threshold
    if peakAmps(i) > miniHeight(i)
        peakAmpsFilt(end+1) = peakAmps(i);
        peakLocsFilt(end+1) = peakLocs(i);
    end
end
% Interval filter
flag = 0;
ii = [];
miniDistance = ceil(miniDistance*fs);
for i = 2:length(peakLocsFilt)
    if (peakLocsFilt(i) - peakLocsFilt(i-1-flag)) <  miniDistance
        ii(end+1) = i;
        flag = 1;
    else
        flag = 0;
    end
end
peakLocsFilt(ii) = [];
peakAmpsFilt(ii) = [];

if isempty(peakLocsFilt)
    disp('Warning. No peaks were identified.')
end

numPeaks = length(peakAmps);
bpm = ceil(60*numPeaks / ceil(length(ppgFilt)/fs)); % Beats per minute
if bpm < 36
    disp('Warning. A small number of peaks were identified.')
end

miniHeightLocs = peakLocs/fs; % Back to real time
peakLocsFilt = peakLocsFilt/fs; 




