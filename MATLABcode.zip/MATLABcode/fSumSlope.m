function sumDiff = fSumSlope(ppg, fs)
L = length(ppg);
numSamples = ceil(0.128*fs);
posDiff = zeros(L, 1);
sumDiff = zeros(L, 1);
for i = 2: L
    temp = ppg(i) - ppg(i-1);
    if temp < 0
        posDiff(i) = -temp; 
    end
    sumDiff(i) = sum(posDiff(i: -1: max(1,i-numSamples)));
end
end
