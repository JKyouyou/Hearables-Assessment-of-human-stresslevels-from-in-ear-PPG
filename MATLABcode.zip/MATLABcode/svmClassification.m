%% 3D Plot
Y = hrvMetricsTb87.6l(:, end); YCell = table2cell(Y);
X = hrvMetricsTbl(:, [1 2 3]); XMtx = table2array(X);

j = 1; 
YUniq = unique(YCell)';
figure
hold on
for i = YUniq
    Xgrp = XMtx(strcmp(i, YCell), :);    scatter3(Xgrp(:,1), Xgrp(:,2), Xgrp(:,3), 42, '.');
    j = j+1;
end
xlabel(X.Properties.VariableNames{1}), ylabel(X.Properties.VariableNames{2}), zlabel(X.Properties.VariableNames{3}); 
legend(YUniq);

%% Multi-classes classification SVM
t = templateSVM('Standardize', 1);
mdl = fitcecoc(X(:, [1 2]), YCell, 'Learners', t, 'Coding', 'onevsone');

%% Visualise boundaries

d = .00002;
x1Range = min(XMtx(:,1)): d: max(XMtx(:,1));
x2Range = min(XMtx(:,2)): d: max(XMtx(:,2));
[xx1, xx2] = meshgrid(x1Range,x2Range);
XGrid = [xx1(:) xx2(:)];

predictedClasses = predict(mdl, XGrid);
figure
gscatter(xx1(:), xx2(:), predictedClasses, [[0 0.4470 0.7410]; [0.8500 0.3250 0.0980];...
    [0.9290 0.6940 0.1250]; [0.4940 0.1840 0.5560]; [0.4660 0.6740 0.1880]],...
    '.', 10);
axis tight
legend(unique(predictedClasses)), xlabel('LF'), ylabel('HF')

%%
figure
cvMdl = crossval(mdl, 'KFold', 5);
oofLabel = kfoldPredict(cvMdl);
confMat = confusionchart(YCell, oofLabel, 'RowSummary', 'total-normalized');
